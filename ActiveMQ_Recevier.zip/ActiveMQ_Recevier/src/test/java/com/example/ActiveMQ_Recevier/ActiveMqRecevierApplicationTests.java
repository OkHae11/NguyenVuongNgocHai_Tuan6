package com.example.ActiveMQ_Recevier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActiveMqRecevierApplicationTests {

	@Test
	void contextLoads() {
	}

}
