package com.example.ActiveMQ_Sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActiveMqSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
