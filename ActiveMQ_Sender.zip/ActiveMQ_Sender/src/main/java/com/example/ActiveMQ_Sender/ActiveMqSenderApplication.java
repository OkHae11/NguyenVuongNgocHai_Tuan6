package com.example.ActiveMQ_Sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActiveMqSenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActiveMqSenderApplication.class, args);
	}

}
